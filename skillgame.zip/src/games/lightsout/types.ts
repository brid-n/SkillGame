export interface TileState {
  lit: boolean;
}
